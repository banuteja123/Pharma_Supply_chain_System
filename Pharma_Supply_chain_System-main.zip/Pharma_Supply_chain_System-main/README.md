# Pharma_Supply_chain_System


Creating a Product:
This step adds a new product to the blockchain with its details (name, manufacturer, manufacture date, expiry date).
If successful, it will print a confirmation message.
Updating the Product Status:
This step updates the status of the product (e.g., "In Transit").
If successful, it will print a confirmation message.
Retrieving Product Details:
This step retrieves and displays the details of the product stored on the blockchain.
